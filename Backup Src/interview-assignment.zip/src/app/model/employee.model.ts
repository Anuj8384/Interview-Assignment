export interface  IEmployee {
    employee_age: Number;
    employee_name: String;
    employee_salary: Number;
    id: Number ;
    profile_image: String;
}
